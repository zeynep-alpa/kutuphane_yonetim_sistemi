SELECT Uyeler.UyeAdi, Uyeler.UyeSoyadi, COUNT(*) AS OduncKitapSayisi
FROM OduncKitaplar
INNER JOIN Uyeler ON OduncKitaplar.UyeID = Uyeler.UyeID
GROUP BY Uyeler.UyeAdi, Uyeler.UyeSoyadi
ORDER BY OduncKitapSayisi DESC
LIMIT 1;
